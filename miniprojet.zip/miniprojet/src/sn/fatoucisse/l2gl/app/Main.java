package sn.fatoucisse.l2gl.app;

import sn.fatoucisse.l2gl.app.model.Etudiant;
import sn.fatoucisse.l2gl.app.model.Module;
import sn.fatoucisse.l2gl.app.model.Note;


public class Main {
    public static void main(String[] args){
        Etudiant etudiant1=new
                Etudiant("FATOU Cisse ","FC01");
        Etudiant etudiant2=new
               Etudiant("C02");
        try {
            Etudiant etudiant3 = new
                    Etudiant("Amina Diop","");

        } catch (IllegalArgumentException e) {
            System.out.println("Erreur attrapée : " + e.getMessage());
        }
        System.out.println(etudiant1);
        System.out.println(etudiant2);
        System.out.println("TD2 OK - Java fonctionne");

        // 2 paramètres (coefficient par défaut = 1.0)
        Module module1 = new Module("INF01 ", "programmation Java ");

// 3 paramètres
        Module module2 = new Module(" MAT01 ", "Mathématiques ", 3.0);

        System.out.println(module1);
        System.out.println(module2);

    // Créer une note valide
        Note note1 = new Note(etudiant1, module1, 20.0);
        System.out.println(note1);
        System.out.println(" Points : "  + note1.points());

// Note invalide → exception
        try {
            Note note2 = new Note(etudiant1, module1, 25.0);
        } catch (IllegalArgumentException e) {
            System.out.println("Erreur attrapée : "  + e.getMessage());
        }

        System.out.println(etudiant1);
        System.out.println(module1);
        System.out.println(note1);

        System.out.println(" BILAN TD2: Etudiants créés: "  + Etudiant.getCompteur() +
                   "  Dernière note: " + note1.getValeur() + " /20  "+
                   "  Points (coeff): "  + note1.points());

    }

}
