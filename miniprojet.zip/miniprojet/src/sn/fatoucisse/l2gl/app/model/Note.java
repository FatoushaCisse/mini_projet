package sn.fatoucisse.l2gl.app.model;

public class Note {

    private Etudiant etudiant;
    private Module module;
    private double valeur;


    public Note(Etudiant etudiant, Module module, double valeur) {
        if (etudiant == null) {
            throw new IllegalArgumentException("L'étudiant ne peut pas être null");
        }
        if (module == null) {
            throw new IllegalArgumentException("Le module ne peut pas être null");
        }
        if (valeur < 0 || valeur > 20) {
            throw new IllegalArgumentException("La valeur doit être entre 0 et 20");
        }
        this.etudiant = etudiant;
        this.module = module;
        this.valeur = valeur;
    }


    public Etudiant getEtudiant() { return etudiant; }
    public Module getModule() { return module; }
    public double getValeur() { return valeur; }

    public void setValeur(double valeur) {
        if (valeur < 0 || valeur > 20) {
            throw new IllegalArgumentException("La valeur doit être entre 0 et 20");
        }
        this.valeur = valeur;
    }


    public double points() {
        return valeur * module.getCoefficient();
    }

//    @Override
//    public String toString() {
//        return "Note{etudiant=" + etudiant.getNom() + ", module=" + module.getLibelle() + ", valeur=" + valeur + "}";
//    }

    @Override
    public String toString() {
        return " Note{etudiant=" + etudiant.getMatricule() + " , module="  + module.getCode() + " , valeur=" + valeur + " , points="  + points() + " } ";
    }
}



