package sn.fatoucisse.l2gl.app.model;

public class Etudiant {

    private String matricule;

    private String nom;

    private static int compteur=0;

    public String getNom(){
        return nom;
    }

    public void setNom( String nom){
        this.nom= nom;
    }

    public String getMatricule(){
        return matricule;
    }

    public void setMatricule( String matricule){
        this.matricule=matricule;
    }

    public static int getCompteur(){
        return compteur;
    }

    public Etudiant (String nom, String matricule){
            if (matricule == null || matricule.isBlank()) {
                throw new IllegalArgumentException(" Le matricule ne peut pas être vide ");
            }
            if (nom == null || nom.isBlank()) {
                throw new IllegalArgumentException(" Le nom ne peut pas être vide ");
            }
            this.matricule = matricule;
            this.nom = nom;
            compteur++;
        }

    public Etudiant(String matricule) {
        this(matricule, "Inconnu");
    }

//    @Override
//    public String toString(){
//        return "Nom:"+nom +"Matricule:" +matricule;
//    }
@Override
public String toString() {
    return " Etudiant{matricule="  + matricule + " , nom=" + nom +  "} ";
}

    void afficher(){
        System.out.println("Nom:" +nom + "Matricule" +matricule);
    }
}


