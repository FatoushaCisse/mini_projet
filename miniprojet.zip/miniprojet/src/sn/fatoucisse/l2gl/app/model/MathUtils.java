package sn.fatoucisse.l2gl.app.model;

public class MathUtils {
}
